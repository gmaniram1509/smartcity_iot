import { useState, useEffect, useCallback } from "react";
import SensorGrid    from "./components/SensorGrid";
import AlertFeed     from "./components/AlertFeed";
import LiveChart     from "./components/LiveChart";
import ZoneMap       from "./components/ZoneMap";
import PipelineBar   from "./components/PipelineBar";

const API = process.env.REACT_APP_API_URL || "http://localhost:6000";
const POLL_MS = 5000;

// ── Global styles injected once ──────────────────────────────
const globalStyle = `
  * { margin:0; padding:0; box-sizing:border-box; }
  body {
    background: #050a0f;
    color: #c8dde8;
    font-family: 'Inter', sans-serif;
    min-height: 100vh;
  }
  body::before {
    content:'';
    position:fixed; inset:0;
    background-image:
      linear-gradient(rgba(0,212,255,0.025) 1px, transparent 1px),
      linear-gradient(90deg, rgba(0,212,255,0.025) 1px, transparent 1px);
    background-size: 40px 40px;
    pointer-events:none; z-index:0;
  }
  ::-webkit-scrollbar { width:4px; }
  ::-webkit-scrollbar-track { background:#0a1520; }
  ::-webkit-scrollbar-thumb { background:#1a3040; border-radius:2px; }
`;

export default function App() {
  const [readings,    setReadings]    = useState({});
  const [events,      setEvents]      = useState([]);
  const [summary,     setSummary]     = useState({});
  const [lastPoll,    setLastPoll]    = useState(null);
  const [pollCount,   setPollCount]   = useState(0);
  const [apiError,    setApiError]    = useState(false);
  const [chartHistory, setChartHistory] = useState([]);

  const fetchAll = useCallback(async () => {
    try {
      const [rRes, eRes, sRes] = await Promise.all([
        fetch(`${API}/readings?limit=10&minutes=30`),
        fetch(`${API}/events?limit=15`),
        fetch(`${API}/summary?minutes=10`),
      ]);

      if (rRes.ok) {
        const data = await rRes.json();
        setReadings(data.readings || {});

        // Build chart history point from latest readings
        const point = { time: new Date().toLocaleTimeString() };
        for (const [sid, items] of Object.entries(data.readings || {})) {
          if (items[0]) {
            if (sid.startsWith("air")) point.pm25  = parseFloat(items[0].pm25_mean  || 0);
            if (sid.startsWith("temp")) point.temp = parseFloat(items[0].value_mean || 0);
            if (sid.startsWith("traffic")) point.congestion = parseFloat(items[0].congestion_index_mean || 0);
          }
        }
        setChartHistory(prev => [...prev.slice(-29), point]);
      }

      if (eRes.ok) {
        const data = await eRes.json();
        setEvents(data.events || []);
      }

      if (sRes.ok) {
        const data = await sRes.json();
        setSummary(data.zones || {});
      }

      setApiError(false);
      setLastPoll(new Date());
      setPollCount(c => c + 1);
    } catch (e) {
      setApiError(true);
    }
  }, []);

  useEffect(() => {
    fetchAll();
    const id = setInterval(fetchAll, POLL_MS);
    return () => clearInterval(id);
  }, [fetchAll]);

  const criticalCount = events.filter(e => e.severity === "CRITICAL").length;

  return (
    <>
      <style>{globalStyle}</style>
      <div style={{ position: "relative", zIndex: 1 }}>

        {/* ── HEADER ─────────────────────────────────────── */}
        <header style={{
          position: "sticky", top: 0, zIndex: 100,
          background: "rgba(5,10,15,0.94)",
          backdropFilter: "blur(20px)",
          borderBottom: "1px solid #1a3040",
          padding: "12px 28px",
          display: "flex", alignItems: "center",
          justifyContent: "space-between",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div style={{
              fontFamily: "'Space Mono', monospace",
              fontSize: 22, fontWeight: 700,
              color: "#00d4ff",
              textShadow: "0 0 24px rgba(0,212,255,0.5)",
              letterSpacing: 3,
            }}>
              NEXUS<span style={{ color: "#c8dde8" }}>CITY</span>
            </div>
            <div style={{
              fontSize: 10, letterSpacing: 3,
              textTransform: "uppercase", color: "#4a6a7a",
              borderLeft: "1px solid #1a3040", paddingLeft: 16,
            }}>
              Smart IoT Monitoring System
            </div>
          </div>

          <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
            {[
              { label: "Sensors", value: Object.keys(readings).length },
              { label: "Events",  value: events.length },
              { label: "Polls",   value: pollCount },
              { label: "Last Update", value: lastPoll
                  ? lastPoll.toLocaleTimeString() : "--" },
            ].map(({ label, value }) => (
              <div key={label} style={{ textAlign: "center" }}>
                <div style={{
                  fontFamily: "'Space Mono', monospace",
                  fontSize: 13, color: "#00d4ff",
                }}>{value}</div>
                <div style={{
                  fontSize: 9, letterSpacing: 2,
                  textTransform: "uppercase", color: "#4a6a7a",
                }}>{label}</div>
              </div>
            ))}

            {/* Live / Error badge */}
            <div style={{
              display: "flex", alignItems: "center", gap: 6,
              background: apiError
                ? "rgba(255,59,92,0.08)" : "rgba(0,255,157,0.08)",
              border: `1px solid ${apiError ? "rgba(255,59,92,0.3)" : "rgba(0,255,157,0.3)"}`,
              padding: "4px 12px", borderRadius: 20,
              fontSize: 10, letterSpacing: 2,
              color: apiError ? "#ff3b5c" : "#00ff9d",
              fontFamily: "'Space Mono', monospace",
            }}>
              <div style={{
                width: 6, height: 6, borderRadius: "50%",
                background: apiError ? "#ff3b5c" : "#00ff9d",
                boxShadow: `0 0 8px ${apiError ? "#ff3b5c" : "#00ff9d"}`,
                animation: "pulse 1.5s infinite",
              }} />
              {apiError ? "OFFLINE" : "LIVE"}
            </div>
          </div>
        </header>

        {/* ── CRITICAL ALERT BANNER ─────────────────────── */}
        {criticalCount > 0 && (
          <div style={{
            background: "rgba(255,59,92,0.12)",
            borderBottom: "1px solid rgba(255,59,92,0.4)",
            padding: "8px 28px",
            display: "flex", alignItems: "center", gap: 10,
            fontFamily: "'Space Mono', monospace", fontSize: 11,
            color: "#ff3b5c", letterSpacing: 2,
          }}>
            <span style={{ fontSize: 14 }}>🚨</span>
            {criticalCount} ACTIVE CRITICAL ALERT{criticalCount > 1 ? "S" : ""}
            {" — "}
            {events.find(e => e.severity === "CRITICAL")?.message?.slice(0, 80)}...
          </div>
        )}

        {/* ── MAIN GRID ─────────────────────────────────── */}
        <main style={{
          padding: "20px 28px",
          display: "grid",
          gridTemplateColumns: "1fr 1fr 1fr",
          gap: 16,
        }}>
          {/* Sensor cards — full width */}
          <div style={{ gridColumn: "1 / 4" }}>
            <SensorGrid readings={readings} />
          </div>

          {/* Chart — 2 cols */}
          <div style={{ gridColumn: "1 / 3" }}>
            <LiveChart history={chartHistory} />
          </div>

          {/* Zone map — 1 col */}
          <div style={{ gridColumn: "3" }}>
            <ZoneMap summary={summary} />
          </div>

          {/* Alerts — full width */}
          <div style={{ gridColumn: "1 / 4" }}>
            <AlertFeed events={events} />
          </div>

          {/* Pipeline — full width */}
          <div style={{ gridColumn: "1 / 4" }}>
            <PipelineBar readings={readings} pollCount={pollCount} />
          </div>
        </main>

        <style>{`
          @keyframes pulse {
            0%,100%{opacity:1;transform:scale(1)}
            50%{opacity:0.4;transform:scale(0.8)}
          }
        `}</style>
      </div>
    </>
  );
}
